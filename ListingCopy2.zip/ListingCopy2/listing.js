// Sri Kavya Dindu
// listing.js

$(document).ready(function()
{
  $('.listing_address').mouseover(function()
  {
    $(this).closest('.listing').find('.house').animate({'left':'10px'});
    $(this).closest('.listing').find('.glass').fadeIn(500);
  });
  $('.listing_address').mouseout(function(){
    $(this).closest('.listing').find('.house').animate({'left':'25px'});
    $(this).closest('.listing').find('.glass').fadeOut(500);
  });
});