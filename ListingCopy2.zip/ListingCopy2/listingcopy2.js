/*****************************************************************************************
Create a .js file to work with the sold.html page that will use jQuery to animate the 
images as demonstrated in this short video clip.
Note: The events are triggered by clicking the mouse. Modify the sold.html page as needed.
*****************************************************************************************/

$(document).ready(function() {
	$('.listing_address').click(function(){
		if ($(this).parent().is('.open')) {
      $(this).closest('.listing').find('.listing_detail_container').animate({'height':'0'},500);
			$(this).closest('.listing').find('.house').animate({'left':'25px'});
      $(this).closest('.listing').find('.glass').fadeOut(500);
			$(this).closest('.listing').removeClass('open');
		}
    else{
      var newHeight = $(this).closest('.listing').find('.listing_detail').height() + 'px';
      $(this).closest('.listing').find('.listing_detail_container').animate({'height':newHeight},500);
			$(this).closest('.listing').find('.house').animate({'left':'10px'});
      $(this).closest('.listing').find('.glass').fadeIn(500);
			$(this).closest('.listing').addClass('open');
		}
	});  
  findAnchorLink();
  
  setInterval("rotateImages()", 3000);
});

function findAnchorLink(){
	if (location.href.indexOf('#') != -1) {
		var namedAnchor = window.location.hash;
		var faqToFind = namedAnchor + ' .listing_address'; 
		$(faqToFind).trigger('click');
	}
}

function rotateImages() {
  var oCurPhoto = $('#hero div.current');
  var oNxtPhoto = oCurPhoto.next();
  if (oNxtPhoto.length == 0)//no more images
    oNxtPhoto = $('#hero div:first');

  oCurPhoto.removeClass('current').addClass('previous');
  oNxtPhoto.css({ opacity: 0.0 }).addClass('current')
  .animate({ opacity: 1.0 }, 1000,
           function() {
             oCurPhoto.removeClass('previous');
           });
}

